To use the Police_Stations_HSIP.lyr layer file, which displays the Police Stations layer 
with the federal Homeland Security Working Group symbology, in ArcGIS 9.x, you 
must first install the ERS_v2_Operations_S1_sym.ttf True Type font file 
included in this .zip archive.

For reference see http://www.fgdc.gov/HSWG/ref_pages/Operations_ref.htm.
